import { styled } from '@linaria/react'

export const Container = styled.div`
  position: relative;
  display: flex;
  flex-direction: column;
`
